"""Ingestion module for LocalBrain."""
