# Google Drive Connector

Syncs files and documents from Google Drive.
