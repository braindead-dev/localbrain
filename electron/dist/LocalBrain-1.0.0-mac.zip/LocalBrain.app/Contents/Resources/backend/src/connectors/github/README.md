# GitHub Connector

Processes GitHub projects
