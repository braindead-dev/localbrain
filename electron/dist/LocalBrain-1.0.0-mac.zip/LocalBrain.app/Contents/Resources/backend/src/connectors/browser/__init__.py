"""Browser History Connector for LocalBrain"""

from .browser_connector import BrowserConnector

__all__ = ["BrowserConnector"]
