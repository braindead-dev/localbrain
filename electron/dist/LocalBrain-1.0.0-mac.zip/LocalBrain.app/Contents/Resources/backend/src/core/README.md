# Core Services

Essential backend services that power the main functionality of LocalBrain.
