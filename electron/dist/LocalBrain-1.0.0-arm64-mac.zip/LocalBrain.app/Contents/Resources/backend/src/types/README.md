# Types

TypeScript type definitions and interfaces.
