# Chunks

Document chunks and text segments storage.
